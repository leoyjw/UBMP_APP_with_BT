package com.clj.blesample;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentHostCallback;

import android.Manifest;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattService;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.method.ScrollingMovementMethod;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.clj.blesample.operation.OperationActivity;
import com.clj.fastble.BleManager;
import com.clj.fastble.callback.BleIndicateCallback;
import com.clj.fastble.callback.BleNotifyCallback;
import com.clj.fastble.callback.BleReadCallback;
import com.clj.fastble.callback.BleWriteCallback;
import com.clj.fastble.data.BleDevice;
import com.clj.fastble.exception.BleException;
import com.clj.fastble.utils.HexUtil;

import org.w3c.dom.Text;

import java.math.BigInteger;
import java.nio.ByteOrder;

public class ProfileActivity extends AppCompatActivity {

    static{
        System.loadLibrary("testing_c");
    }

    public native int CalculateECG(int num, int en);

    private Button btn_main_current;
    private Button btn_main_device;
    private Button btn_profile_calibration;
    private TextView txt_profile_name_ans;
    private EditText txt_current_bp_ans;
    private EditText txt_current_hr_ans;

    private TextView txt_profile_device_name;
    private TextView txt_profile_service_name;
    private TextView txt_profile_received_signal;

    private BleDevice bleDevice;
    BluetoothGattCharacteristic characteristic;
    BluetoothGatt gatt;

    private int[] ECG_Signal= new int[1000];
    private int[] PPG_Signal= new int[1000];

    private int i = 0;

    private byte[] Mydata;
    private byte[] ECG;
    private byte[] PPG;
    private int Sample_Num = 100;





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        setContentView(R.layout.activity_profile);
        TinyDB tinydb = new TinyDB(this);


        btn_main_current = findViewById(R.id.btn_main_current);
        btn_main_device = findViewById(R.id.btn_main_device);
        btn_profile_calibration = findViewById(R.id.btn_profile_calibration);
        txt_profile_name_ans = findViewById(R.id.txt_profile_name_ans);
        txt_current_bp_ans = findViewById(R.id.txt_current_bp_ans);
        txt_current_hr_ans = findViewById(R.id.txt_current_hr_ans);
        txt_profile_received_signal = findViewById(R.id.txt_profile_received_signal);
        txt_profile_device_name = findViewById(R.id.txt_profile_device_name);
        txt_profile_service_name = findViewById(R.id.txt_service_name);

        // info of the profile
        txt_profile_name_ans.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                txt_profile_name_ans.setText("");
            }
        });

        txt_current_bp_ans.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                txt_current_bp_ans.setText("");
            }
        });

        txt_current_hr_ans.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                txt_current_hr_ans.setText("");
            }
        });

        // bottom buttons
        btn_main_current.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ProfileActivity.this, HomeActivity.class);
                startActivity(intent);
            }
        });

        btn_main_device.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ProfileActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });

        btn_profile_calibration.setOnClickListener(new View.OnClickListener(){
            @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN_MR2)
            @Override
            public void onClick(View v) {

                String SBP = txt_current_bp_ans.getText().toString();
                String DBP = txt_current_hr_ans.getText().toString();
                int SBP_cali = Integer.parseInt(SBP);
                int DBP_cali = Integer.parseInt(DBP);


                i=0;
                ECG_Signal= new int[1000];
                PPG_Signal= new int[1000];


                bleDevice = BleManager.getInstance().getAllConnectedDevice().get(0);
                gatt = BleManager.getInstance().getBluetoothGatt(bleDevice);
                characteristic = gatt.getServices().get(2).getCharacteristics().get(1);

                // Toast.makeText(ProfileActivity.this, bleDevice.getName(), Toast.LENGTH_SHORT).show();
                txt_profile_device_name.setText(bleDevice.getName());
                txt_profile_service_name.setText(gatt.getServices().get(2).getUuid().toString());
              //  txt_profile_received_signal.setText(characteristic.getUuid().toString());

                BleManager.getInstance().notify(
                        bleDevice,
                        characteristic.getService().getUuid().toString(),
                        characteristic.getUuid().toString(),
                        new BleNotifyCallback() {

                            @Override
                            public void onNotifySuccess() {
                                runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {

                                    }
                                });
                            }

                            @Override
                            public void onNotifyFailure(final BleException exception) {
                                runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {

                                    }
                                });
                            }

                            @Override
                            public void onCharacteristicChanged(byte[] data) {
                                runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {

                                        Mydata = characteristic.getValue();
                                        ECG = new byte[4];

                                        PPG = new byte[4];

                                        System.arraycopy(Mydata, 0, ECG, 0, 4);
                                        System.arraycopy(Mydata, 4, PPG, 0, 4);



                                        if (i < Sample_Num){
                                        // ECG_Signal[i] = 2;
                                            int d = little2big(fromByteArray(ECG));
                                            int c = little2big(fromByteArray(PPG));

                                             ECG_Signal[i] = d;
                                             PPG_Signal[i] = c;
                                            String TestingValue = Integer.toString(d)+"    " +Integer.toString(c);

                                            i = i +1;
                                          }
                                          if (i==Sample_Num){


                                              txt_profile_received_signal.setText("ST");




                                              tinydb.putString("parameter","123");
                                          }









                                    }
                                });
                            }
                        });





            }
        });

    }
    // packing an array of 4 bytes to an int, big endian, clean code
    int fromByteArray(byte[] bytes) {
        return ((bytes[0] & 0xFF) << 24) |
                ((bytes[1] & 0xFF) << 16) |
                ((bytes[2] & 0xFF) << 8 ) |
                ((bytes[3] & 0xFF) << 0 );
    }
    int little2big(int i) {
        return (i&0xff)<<24 | (i&0xff00)<<8 | (i&0xff0000)>>8 | (i>>24)&0xff;
    }





}
