package com.clj.blesample;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCharacteristic;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.ViewDebug;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.clj.fastble.BleManager;
import com.clj.fastble.callback.BleNotifyCallback;
import com.clj.fastble.data.BleDevice;
import com.clj.fastble.exception.BleException;

public class HomeActivity extends AppCompatActivity {

    static{
        System.loadLibrary("testing_c");
    }
    public native int CalculateECG(int num, int en);


    private TextView txt_bp;


    private Button btn_main_current;
    private Button btn_main_history;
    private Button btn_main_device;
    private Button btn_main_profile;


    private BleDevice bleDevice;
    BluetoothGattCharacteristic characteristic;
    BluetoothGatt gatt;

    private int[] ECG_Signal= new int[1000];
    private int[] PPG_Signal= new int[1000];

    private int i = 0;

    private byte[] Mydata;
    private byte[] ECG;
    private byte[] PPG;
    private int Sample_Num = 1000;








    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        TinyDB tinydb = new TinyDB(this);
//        BleManager.getInstance().init(getApplication());
//        BleManager.getInstance()
//                .enableLog(true)
//                .setReConnectCount(1, 5000)
//                .setOperateTimeout(5000);

        txt_bp = findViewById(R.id.BloodPressure);
        btn_main_current = findViewById(R.id.btn_main_current);
        btn_main_history = findViewById(R.id.btn_main_history);
        btn_main_device = findViewById(R.id.btn_main_device);
        btn_main_profile = findViewById(R.id.btn_main_profile);

        btn_main_current.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Toast.makeText(HomeActivity.this, "This is current button", Toast.LENGTH_SHORT).show();
//                String msg_json = msg.obj.toString().substring(msg.obj.toString().indexOf("[")+1, msg.obj.toString().indexOf("]"))
            }
        });

        btn_main_history.setOnClickListener(new View.OnClickListener(){
            @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN_MR2)
            @Override
            public void onClick(View v){
               // int i = CalculateECG(10000,1000);
              //  String d = Integer.toString(i);
              //  Toast.makeText(HomeActivity.this, d, Toast.LENGTH_SHORT).show();

                i=0;
                ECG_Signal= new int[1000];
                PPG_Signal= new int[1000];


                bleDevice = BleManager.getInstance().getAllConnectedDevice().get(0);
                gatt = BleManager.getInstance().getBluetoothGatt(bleDevice);
                characteristic = gatt.getServices().get(2).getCharacteristics().get(1);

                // Toast.makeText(ProfileActivity.this, bleDevice.getName(), Toast.LENGTH_SHORT).show();
               // txt_profile_device_name.setText(bleDevice.getName());
               // txt_profile_service_name.setText(gatt.getServices().get(2).getUuid().toString());
                //  txt_profile_received_signal.setText(characteristic.getUuid().toString());

                BleManager.getInstance().notify(
                        bleDevice,
                        characteristic.getService().getUuid().toString(),
                        characteristic.getUuid().toString(),
                        new BleNotifyCallback() {

                            @Override
                            public void onNotifySuccess() {
                                runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {

                                    }
                                });
                            }

                            @Override
                            public void onNotifyFailure(final BleException exception) {
                                runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {

                                    }
                                });
                            }

                            @Override
                            public void onCharacteristicChanged(byte[] data) {
                                runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {

                                        Mydata = characteristic.getValue();
                                        ECG = new byte[4];

                                        PPG = new byte[4];

                                        System.arraycopy(Mydata, 0, ECG, 0, 4);
                                        System.arraycopy(Mydata, 4, PPG, 0, 4);



                                        if (i < Sample_Num){
                                            // ECG_Signal[i] = 2;
                                            int d = little2big(fromByteArray(ECG));
                                            int c = little2big(fromByteArray(PPG));

                                            ECG_Signal[i] = d;
                                            PPG_Signal[i] = c;
                                            String TestingValue = Integer.toString(d)+"    " +Integer.toString(c);
                                            //txt_profile_received_signal.setText(TestingValue);
                                            i = i +1;
                                        }
                                        if (i==Sample_Num){

                                            String para = tinydb.getString("parameter");


                                            txt_bp.setText(para);

                                        }









                                    }
                                });
                            }
                        });



            }
        });

        btn_main_device.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intent = new Intent(HomeActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });

        btn_main_profile.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intent = new Intent(HomeActivity.this, ProfileActivity.class);
                startActivity(intent);
            }
        });


    }

    // packing an array of 4 bytes to an int, big endian, clean code
    int fromByteArray(byte[] bytes) {
        return ((bytes[0] & 0xFF) << 24) |
                ((bytes[1] & 0xFF) << 16) |
                ((bytes[2] & 0xFF) << 8 ) |
                ((bytes[3] & 0xFF) << 0 );
    }
    int little2big(int i) {
        return (i&0xff)<<24 | (i&0xff00)<<8 | (i&0xff0000)>>8 | (i>>24)&0xff;
    }





}
